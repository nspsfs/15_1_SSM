#include <iostream>
#include "imageFusion.h"
#include "changeViewPoint.h"

using namespace std;

int main()
{
	CVP cvp;
	IplImage* disparity = cvLoadImage("image/test1_disparity.jpg");
	IplImage* rightImage = cvLoadImage("image/test1_R.jpg");
	IplImage* leftImage = cvLoadImage("image/test1_L.jpg");
	IplImage* convertImage = NULL;

	cvp.setimg(disparity, rightImage, leftImage);
	cvp.runcvt(&convertImage);
	cvShowImage("leftImage", leftImage);
	cvShowImage("rightImage", rightImage);
	cvShowImage("convertImage", convertImage);


	Fusion fusion;
	IplImage* image1 = cvLoadImage("test2_1.bmp");
	IplImage* image2 = cvLoadImage("test2_2.bmp");
	IplImage* multiFocusImage=NULL;

	fusion.setImg(image1, image2);
	fusion.sml(&multiFocusImage);

	cvShowImage("MultiFocusImage", multiFocusImage);


	cvWaitKey(0);
	return 0;
}